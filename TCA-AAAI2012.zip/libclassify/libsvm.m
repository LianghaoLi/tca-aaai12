function [ accuracy ] = libsvm( train_labels,Xtrain,test_labels,Xtest,options )
%LIBSVM libsvm wrapper

model = svmtrain(train_labels, Xtrain, options);
[~, accuracy, ~] = svmpredict(test_labels, Xtest, model);
accuracy = accuracy(1);

end