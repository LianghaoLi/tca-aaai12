function [ Pw_z,Pz_d,Pd,Pz_q,Pq,logL,F_logL ] = pLSA( X,option )
if isfield(option, 'ntopics')
    ntopics = option.ntopics;
else
    ntopics = 100;
end

if isfield(option, 'niters')
    niters = option.niters;
else
    niters = 100;
end

if isfield(option, 'heldout')
    heldout = option.heldout;
else
    heldout = 0;
end

if isfield(option, 'fiiters')
    fiiters = option.fiiters;
else
    fiiters = 10;
end

if isfield(option, 'fifreq')
    fifreq = option.fifreq;
else
    fifreq = 10;
end

if isfield(option, 'display')
    display = option.display;
else
    display = false;
end

%PLSA Summary of this function goes here
%   Detailed explanation goes here

% split dataset into training and test data
ndocs = size(X,2);
ntrain = ceil((1 - heldout) * ndocs);

Xtrain = X(:,1:ntrain);
Xtest = X(:,1+ntrain:end);

% initialization
[Pd,Pz_d,Pw_z] = pLSA_init(Xtrain,ntopics);
Pw_d = mex_Pw_d(Xtrain,Pw_z,Pz_d);

% ======================== EM ========================
logL = zeros(niters,1);
F_logL = zeros(floor(niters/fifreq),1);
for iter = 1:niters
    % EM, update the parameters and avoid the big posterior
    [Pw_z,Pz_d] = mex_EMstep(Xtrain,Pw_d,Pw_z,Pz_d);
    
    % update the normalization constant Pw_d
    Pw_d = mex_Pw_d(Xtrain,Pw_z,Pz_d);
    
    % compute log likelihood
    logL(iter) = mex_logL(Xtrain,Pw_d,Pd);
    if display
        fprintf('EM iter.%d\tlogL=%4.3f\n',iter,logL(iter));
    end
    
    % computer fold-in logL if needed
    if mod(iter,fifreq) == 0 && heldout ~= 0
        n = floor(iter/fifreq);
        [ Pz_q,Pq,F_logL(n)] = pLSA_EMfold(Xtest,Pw_z,fiiters);
        if display
            fprintf('Fold-in logL=%4.3f\n',F_logL(n));
        end
    end
end

% calculate final Pz_q,Pq,final_F_logL when needed
if mod(niters,fifreq) ~= 0 && heldout ~= 0
    [ Pz_q,Pq,final_F_logL] = pLSA_EMfold(Xtest,Pw_z,fiiters);
    F_logL = [F_logL;final_F_logL];
end

% if we don't need heldout verification
if heldout == 0
    Pz_q = [];
    Pq = [];
end

end

