1.add libclassify and plsatools into matlab path
2.use TopicCorrAnalysis\src\run.m to execute program, and use TopicCorrAnalysis\src\analysis.m to see the result