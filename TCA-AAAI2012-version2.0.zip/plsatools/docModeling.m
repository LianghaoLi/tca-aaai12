function [ topicwords ] = docModeling( Pw_z,vocabulary,nwords )
%DOCMODELING Summary of this function goes here
%   Detailed explanation goes here
topicwords = cell(size(Pw_z));

[~,perm] = sort(Pw_z,'descend');
for k = 1:size(Pw_z,2)
    topicwords(:,k) = vocabulary(perm(:,k));
end

if nargin < 3
    nwords = 20;
end
topicwords = topicwords(1:nwords,:);

end

