function [ acc ] = clusterAnalysis( Pz_d,true_labels )
%EVALPLSA Summary of this function goes here
%   Detailed explanation goes here

if size(Pz_d,2) ~= size(true_labels)
    error('size(Pz_d,2) ~= size(true_labels)');
end

ndocs = length(true_labels);
cluster_labels = zeros(ndocs,1);

for d = 1:ndocs
    [maxvalue cluster_labels(d)] = max(Pz_d(:,d));
end

acc = accuracy(true_labels,cluster_labels);

end

