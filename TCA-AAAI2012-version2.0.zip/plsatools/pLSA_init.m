function [ Pd,Pz_d,Pw_z ] = pLSA_init( X,ntopics )
% PLSA_INIT: initilized PLSA model

[nwords,ndocs] = size(X);
Pd = sum(X)./sum(X(:));
Pd = full(Pd);

%
% init mixture components
%
Pz_d = rand(ntopics,ndocs);
C = 1./sum(Pz_d,1);
Pz_d = Pz_d .* repmat(C,ntopics,1);

%
% random assignment
%
Pw_z = rand(nwords,ntopics);
C = 1./sum(Pw_z,1);    % normalize to sum to 1
Pw_z = Pw_z .* repmat(C,nwords,1);

end

