function [ Pz_q,Pq,logL ] = pLSA_EMfold( Xtest,Pw_z,fiiters )
%PLSA_EMFOLD Summary of this function goes here
%   Detailed explanation goes here

% avoid zero Pw_z in test data
ZERO_OFFSET = 1e-7;
Pw_z = Pw_z + ZERO_OFFSET;

ntopics = size(Pw_z,2);

% initialize Pq and Pz_q
[ Pq,Pz_q,dummy ] = pLSA_init( Xtest,ntopics );
Pw_q = mex_Pw_d(Xtest,Pw_z,Pz_q);

% fold-in while keeping Pw_z fixed
for n = 1:fiiters
    [dummy,Pz_q] = mex_EMstep(Xtest,Pw_q,Pw_z,Pz_q);
    Pw_q = mex_Pw_d(Xtest,Pw_z,Pz_q);
end

logL = mex_logL(Xtest,Pw_q,Pq);

end

