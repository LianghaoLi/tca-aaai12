function [ avg_acc ] = libclassifycv( algorithm,labels,X,options,nfolds )
%LIBCLASSIFYCV: the cross-validation interface for libclassify
%   algorithm: specify classification algorithm
%   labels: an m by 1 vector of labels (type must be double).
%   X: an m by n matrix of m instances with n features. It can be dense or
%   sparse (type must be double).
%   options: a string of training options
%   nfolds: specific cross-validation folds

%% process input variables
if strcmp(algorithm,'libsvm') == true
    classifier = @libsvm;
elseif strcmp(algorithm,'liblinear') == true
    classifier = @liblinear;
elseif strcmp(algorithm,'naivebayes') == true
    classifier = @naivebayes;
else
    error([algorithm, ' are not avaiable algorithm:\n']);
end

if ~issparse(X)
    X = sparse(X);
end

if length(labels) ~= size(X,1)
    error('length(labels) ~= size(X,1)');
end

if nargin < 5
    nfolds = 10;
end

%% cross-validation main
indices = crossvalind('Kfold',size(X,1),nfolds);

acc = zeros(nfolds,1);
for i = 1:nfolds
    test = (indices == i); 
    train = ~test;
    
    acc(i) = classifier(labels(train),X(train,:),labels(test),X(test,:),options);
end
avg_acc = mean(acc);

end

