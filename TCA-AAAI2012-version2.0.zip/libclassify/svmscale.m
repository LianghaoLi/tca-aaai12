function [ X ] = svmscale( X,lower,upper )
% SVMSCALE: scaling procedure
% X is the term-document matrix with each row is a instance and each column
% is a feature

if nargin == 1
    lower = 0; upper = 1;
end
ninst = size(X,1);

% find out min/max value
maxvalue = max(X);
minvalue = min(X);

% scale X
nnz = find( maxvalue - minvalue );
C = (upper - lower) ./ (maxvalue(nnz) - minvalue(nnz));

dist_X = X(:,nnz) - repmat(minvalue(nnz),ninst,1);
X(:,nnz) = lower + repmat(C,ninst,1) .* dist_X;

end