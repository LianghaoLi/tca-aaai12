function [ avg_acc ] = libclassify( algorithm,train_labels,Xtrain,test_labels,Xtest,options,ntrain,scale,nruns )
%LIBCLASSIFY a unified wrapper for classification algorithms


%% process input variables
if strcmp(algorithm,'libsvm') == true
    classifier = @libsvm;
elseif strcmp(algorithm,'liblinear') == true
    classifier = @liblinear;
elseif strcmp(algorithm,'naivebayes') == true
    classifier = @naivebayes;
else
    error([algorithm, ' are not avaiable algorithm:\n']);
end

if ~issparse(Xtrain)
    Xtrain = sparse(Xtrain);
end
if ~issparse(Xtest)
    Xtest = sparse(Xtest);
end

if size(Xtrain,2) ~= size(Xtest,2)
    error('size(Xtrain,2) ~= size(Xtest,2)');
end

if length(train_labels) ~= size(Xtrain,1) || length(test_labels) ~= size(Xtest,1)
    error('length(train_labels) ~= size(Xtrain,1) || length(test_labels) ~= size(Xtest,1)');
end

if unique(train_labels) ~= unique(test_labels)
    error('unique(train_labels) ~= unique(test_labels)');
end

% if no scale specific, use false as default if no nruns specific, use 20 as default
if nargin < 8
    scale = false;
    nruns = 20;
elseif nargin < 9
    nruns = 20;
else
    if isempty(scale)
        scale = false;
    end
end

% scale input X
if scale
    Xscale = svmscale([Xtrain;Xtest]);
    Xtrain = Xscale(1:size(Xtrain,1), :);
    Xtest = Xscale(size(Xtrain,1)+1:end, :);
end

%% if 'all' training data is specified to used for training, we don't need N random runs
if strcmp(ntrain,'all') == 1
    avg_acc = classifier(train_labels,Xtrain,test_labels,Xtest,options);
    return;
end

%% Else if training number is specified, averaged accurracies on N random runs are returned
% if input is train data ratio
ninst = length(train_labels);
if round(ntrain) ~= ntrain
    ntrain = ninst * ntrain;
end

class = unique(train_labels);
nclass = length(class);
perclass = round( ntrain / nclass );
if perclass * nclass ~= ntrain
    fprintf('perclass * nclass ~= ntrain');
end
for c = 1:nclass
    if length(find(train_labels == class(c))) < perclass
        error('length(find(train_labels == class(c))) < perclass');
    end
end

acc = zeros(nruns,1);
for i = 1:nruns
    train = false(ninst,1);
    for c = 1:nclass
        idx = find(train_labels == class(c));
        perm = randperm(length(idx));
        rnd = idx(perm(1:perclass));
        train(rnd) = true;
    end
    acc(i) = classifier(train_labels(train),Xtrain(train,:),test_labels,Xtest,options);
end
avg_acc = mean(acc);

end