function [ accuracy ] = naivebayes( train_labels,Xtrain,test_labels,Xtest,options )
%NAIVEBAYES a wrapper for naive bayes classifier in statistical toolbox
%   Detailed explanation goes here

nb = NaiveBayes.fit(Xtrain,train_labels,'Distribution',options);
pred = predict(nb,Xtest);

correct = length(find(test_labels == pred));
total = length(test_labels);

accuracy = 100 * correct / total;
fprintf('Accuracy = %4.4f%% (%d/%d)\n',accuracy,correct,total);

end

