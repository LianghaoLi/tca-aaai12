function [ accuracy ] = liblinear( train_labels,Xtrain,test_labels,Xtest,options )
%LIBLINEAR Summary of this function goes here
%   Detailed explanation goes here

model = train(train_labels, Xtrain, options);
[~, accuracy, ~] = predict(test_labels, Xtest, model);
accuracy = accuracy(1);

end

