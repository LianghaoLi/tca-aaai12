#include "mex.h"
#include "matrix.h"
#include <math.h>
#include <string.h>

/*
  The joint M step in Topic Alignment

  Lianghao Li
*/

void spec_Mstep(double *word, double *doc, double *count, mwSize com_ntopics, mwSize spec_ntopics, mwSize nnz, mwSize nwords, mwSize ndocs, mwSize smooth, double *Pz_dw, double *com_Pw_z, double *spec_Pw_z, double *Pz_dpi, double *mu);

/*
  input:
    prhs[0]: src_word, term-doc matrix elements' row(word) indices of source domain
    prhs[1]: src_doc, term-doc matrix elements' column(doc) indices of source domain
	prhs[2]: src_count, term-doc matrix elements' value of source domain
	prhs[3]: tar_word, term-doc matrix elements' row(word) indices of target domain
	prhs[4]: tar_doc, term-doc matrix elements' column(doc) indices of target domain
	prhs[5]: tar_count, term-doc matrix elements' value of target domain
	prhs[6]: src_Pz_dw, E step topic assignment for source domain
	prhs[7]: tar_Pz_dw, E step topic assignment for target domain
	prhs[8]: info, [0]:nwords [1]:src_ndocs [2]:tar_ndocs [3]:com_ntopics [4]:src_ntopics [5]:tar_ntopics [6]:smooth
  output:
    plhs[0]: com_Pw_z
	plhs[1]: src_Pw_z
	plhs[2]: tar_Pw_z
	plhs[3]: src_Pz_dpi
	plhs[4]: tar_Pz_dpi
	plhs[5]: src_mu
	plhs[6]: tar_mu
*/
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double *src_word, *src_doc, *src_count, *tar_word, *tar_doc, *tar_count, *src_Pz_dw, *tar_Pz_dw, *info, *com_Pw_z, *src_Pw_z, *tar_Pw_z, *src_Pz_dpi, *tar_Pz_dpi, *src_mu, *tar_mu;
    mwSize src_nnz, tar_nnz, nwords, src_ndocs, tar_ndocs, com_ntopics, src_ntopics, tar_ntopics, smooth;
	double sumZ;
	mwSize k, w;

	src_word = mxGetPr(prhs[0]);
	src_doc = mxGetPr(prhs[1]);
	src_count = mxGetPr(prhs[2]);

	tar_word = mxGetPr(prhs[3]);
	tar_doc = mxGetPr(prhs[4]);
	tar_count = mxGetPr(prhs[5]);

	src_Pz_dw = mxGetPr(prhs[6]);
	tar_Pz_dw = mxGetPr(prhs[7]);

	src_nnz = mxGetM(prhs[0]);
	tar_nnz = mxGetM(prhs[3]);

	info = mxGetPr(prhs[8]);
	nwords = info[0];
	src_ndocs = info[1];
	tar_ndocs = info[2];
	com_ntopics = info[3];
	src_ntopics = info[4];
	tar_ntopics = info[5];
	smooth = info[6];

	if(nrhs != 9)
	{
		printf("usage : [ com_Pw_z,src_Pw_z,tar_Pw_z,src_Pz_dpi,tar_Pz_dpi,src_mu,tar_mu ] = mex_joint_Mstep( src_word,src_doc,src_count,tar_word,tar_doc,tar_count,src_Pz_dw,tar_Pz_dw,info );\n");
		return;
	}

	/************************ Main ************************/
	plhs[0] = mxCreateDoubleMatrix(nwords,com_ntopics,mxREAL);
	com_Pw_z = mxGetPr(plhs[0]);

	plhs[1] = mxCreateDoubleMatrix(nwords,src_ntopics,mxREAL);
	src_Pw_z = mxGetPr(plhs[1]);

	plhs[2] = mxCreateDoubleMatrix(nwords,tar_ntopics,mxREAL);
	tar_Pw_z = mxGetPr(plhs[2]);

	plhs[3] = mxCreateDoubleMatrix(com_ntopics + src_ntopics,src_ndocs,mxREAL);
	src_Pz_dpi = mxGetPr(plhs[3]);

	plhs[4] = mxCreateDoubleMatrix(com_ntopics + tar_ntopics,tar_ndocs,mxREAL);
	tar_Pz_dpi = mxGetPr(plhs[4]);

	plhs[5] = mxCreateDoubleMatrix(src_ndocs,1,mxREAL);
	src_mu = mxGetPr(plhs[5]);

	plhs[6] = mxCreateDoubleMatrix(tar_ndocs,1,mxREAL);
	tar_mu = mxGetPr(plhs[6]);

	spec_Mstep(src_word,src_doc,src_count,com_ntopics,src_ntopics,src_nnz,nwords,src_ndocs,smooth,src_Pz_dw,com_Pw_z,src_Pw_z,src_Pz_dpi,src_mu);
	spec_Mstep(tar_word,tar_doc,tar_count,com_ntopics,tar_ntopics,tar_nnz,nwords,tar_ndocs,smooth,tar_Pz_dw,com_Pw_z,tar_Pw_z,tar_Pz_dpi,tar_mu);

	/* do normalization for common topics */
	for(k = 0; k < com_ntopics; k++)
	{
		sumZ = 0;
		for(w = 0; w < nwords; w++)
		{
			sumZ += com_Pw_z[k * nwords + w];
		}

		for(w = 0; w < nwords; w++)
		{
			com_Pw_z[k * nwords + w] /= sumZ;
		}
	}
}

void spec_Mstep(double *word, double *doc, double *count, mwSize com_ntopics, mwSize spec_ntopics, mwSize nnz, mwSize nwords, mwSize ndocs, mwSize smooth, double *Pz_dw, double *com_Pw_z, double *spec_Pw_z, double *Pz_dpi, double *mu)
{
	double sumZ, *sumPz_d_com, *sumPz_d_spec, nPz_dw;
	mwSize ntopics;
	mwSize idx, k;
	mwSize w, d;

	ntopics = com_ntopics + spec_ntopics;

	sumPz_d_com = (double*)malloc(ndocs * sizeof(double));
	sumPz_d_spec = (double*)malloc(ndocs * sizeof(double));
	memset(sumPz_d_com, 0, ndocs * sizeof(double));
	memset(sumPz_d_spec, 0, ndocs * sizeof(double));


	/* loop for common topics */
	for(k = 0; k < com_ntopics; k++)
	{
		for(idx = 0; idx < nnz; idx++)/* loop for each nnz */
		{
			w = word[idx] - 1;
			d = doc[idx] - 1;
			nPz_dw = count[idx] * Pz_dw[idx * ntopics + k];

			com_Pw_z[k * nwords + w] += nPz_dw;
			Pz_dpi[d * ntopics + k] += nPz_dw;

			sumPz_d_com[d] += nPz_dw;
		}
	}

	/* loop for domain specific topics */
	for(k = 0; k < spec_ntopics; k++)
	{
		sumZ = 0;
		for(idx = 0; idx < nnz; idx++)/* loop for each nnz */
		{
			w = word[idx] - 1;
			d = doc[idx] - 1;
			nPz_dw = count[idx] * Pz_dw[idx * ntopics + com_ntopics + k];

			spec_Pw_z[k * nwords + w] += nPz_dw;
			Pz_dpi[d * ntopics + com_ntopics + k] += nPz_dw;

			sumZ += nPz_dw;
			sumPz_d_spec[d] += nPz_dw;
		}

		/* do normalization for spec_Pw_z */
		for(w = 0; w < nwords; w++)
		{
			spec_Pw_z[k * nwords + w] /= sumZ;
		}
	}

	/* do normalization for Pz_dpi and calculate mu */
	for(d = 0; d < ndocs; d++)
	{
		for(k = 0; k < com_ntopics; k++)
		{
			Pz_dpi[d * ntopics + k] /= sumPz_d_com[d];
		}
		for(k = 0; k < spec_ntopics; k++)
		{
			Pz_dpi[d * ntopics + com_ntopics + k] /= sumPz_d_spec[d];
		}
		mu[d] = (sumPz_d_com[d] + smooth) / (sumPz_d_com[d] + sumPz_d_spec[d] + 2 * smooth);
	}

	free(sumPz_d_com);
	free(sumPz_d_spec);
}