function [ result ] = topicCorrAnalysis( data,model,ntrain,algorithm,options )
%% topicCorrAnalysis: Main function for Topic Correlation Analysis
src_labels = data.src_labels;
tar_labels = data.tar_labels;

src_Pd = model.src_Pd;
tar_Pd = model.tar_Pd;
src_mu = model.src_mu;
tar_mu = model.tar_mu;
src_Pz_dpi = model.src_Pz_dpi;
tar_Pz_dpi = model.tar_Pz_dpi;
com_ntopics = model.param.com_ntopics;

% calculate Pz_d
src_Pz_d = convertPz_d(src_Pz_dpi,com_ntopics,src_mu);
tar_Pz_d = convertPz_d(tar_Pz_dpi,com_ntopics,tar_mu);
        
% calculate correlations between domain-specific and common topics
src_topicCorr = correlation(src_Pz_d,src_Pd,com_ntopics);
tar_topicCorr = correlation(tar_Pz_d,tar_Pd,com_ntopics);
        
% calculate correlation across domain with Pearson Correlation Coefficients
topicMapping = corr(src_topicCorr',tar_topicCorr');

% classify with topic correlation analysis
[ result.accuracy,result.aux_accuracy] = classify(topicMapping,src_labels,tar_labels,src_Pz_d,tar_Pz_d,com_ntopics,ntrain,algorithm,options);
end

function [ accuracy,aux_accuracy ] = classify(topicMapping,src_labels,tar_labels,src_Pz_d,tar_Pz_d,com_ntopics,ntrain,algorithm,options)

% topic correlation analysis
com_src_Pz_d = src_Pz_d(1:com_ntopics,:);
com_tar_Pz_d = tar_Pz_d(1:com_ntopics,:);
spec_src_Pz_d = src_Pz_d(com_ntopics+1:end,:);
mapped_tar_Pz_d = topicMapping * tar_Pz_d(com_ntopics+1:end,:);

% auxillary result
aux_accuracy = libclassify( algorithm,src_labels,com_src_Pz_d',tar_labels,com_tar_Pz_d',options,ntrain );

% result of TCA
source = [com_src_Pz_d; spec_src_Pz_d];
target = [com_tar_Pz_d; mapped_tar_Pz_d];
accuracy = libclassify( algorithm,src_labels,source',tar_labels,target',options,ntrain );
end


function [Pz_d] = convertPz_d(Pz_dpi,com_ntopics,mu)
spec_ntopics = size(Pz_dpi,1) - com_ntopics;

com_Pz_d = repmat(mu',com_ntopics,1) .* Pz_dpi(1:com_ntopics,:);
spec_Pz_d = repmat((1-mu)',spec_ntopics,1) .* Pz_dpi(com_ntopics+1:end,:);
Pz_d = [com_Pz_d; spec_Pz_d];
end


function [topicCorr] = correlation(Pz_d,Pd,com_ntopics)

[ntopics,~] = size(Pz_d);
spec_ntopics = ntopics - com_ntopics;

% here we normalized common topic-document distribution in each
% domain to enable Jensn-Shannon divergence calculation
Pd_z = calcPd_z(Pz_d,Pd);
com_Pd_z = Pd_z(:,1:com_ntopics);
spec_Pd_z = Pd_z(:,com_ntopics+1:end);

topicCorr = zeros(spec_ntopics,com_ntopics);
for i = 1:com_ntopics
    com = com_Pd_z(:,i);
    for j = 1:spec_ntopics
        spec = spec_Pd_z(:,j);
        
        % using jensen-shannon divergence
        divergence = jsdiv(com,spec);
        
        if isnan(divergence)
            error('isnan(divergence)');
        else
            topicCorr(j,i) = divergence;
        end
    end
end
end


function [Pd_z] = calcPd_z(Pz_d,Pd)
[ntopics,ndocs] = size(Pz_d);
Pd_z = zeros(ndocs,ntopics);
for k = 1:ntopics
    Pdz = Pz_d(k,:)' .* Pd;
    C = 1/sum(Pdz);
    Pd_z(:,k) = Pdz .* C;
end
end


function [ jsd ] = jsdiv(P,Q)
if (abs(sum(P) - 1) > .00001) || (abs(sum(Q) - 1) > .00001),
    error('Probablities don''t sum to 1.')
end

[~,~,vp] = find(P);
[~,~,vq] = find(Q);
SMOOTH = min([min(vp),min(vq)]);

P = P + SMOOTH;
Q = Q + SMOOTH;

M = (P + Q) / 2;
KL_PM = sum(P .* log2( P ./ M ));
KL_QM = sum(Q .* log2( Q ./ M ));
jsd = (KL_PM + KL_QM) / 2;
end