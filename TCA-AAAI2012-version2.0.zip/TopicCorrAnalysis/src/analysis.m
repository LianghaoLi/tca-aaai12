accuracy = zeros(length(results),1);
aux_accuracy = zeros(size(accuracy));

for i = 1:length(results)
    result = results(i);
    accuracy(i) = result.accuracy;
    aux_accuracy(i) = result.aux_accuracy(1);
end
mean_accuracy = mean(accuracy);
mean_aux_accuracy = mean(aux_accuracy);