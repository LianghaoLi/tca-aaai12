clear all;
clc;

load ../data/comp_vs_rec.mat;

% one can set the random stream to its default value to reproduce the
% experiment results, which equals to ``rand('state',0)'' in Matlab 5 and earlier
RandStream.setDefaultStream(RandStream('swb2712','Seed',0));

% parameters
nruns = 10;
ntopics = 12;
com_proportion = .5;

smooth = 20;
algorithm = 'liblinear';
ntrain = 'all';
niters = 200;
options = '-s 0 -c 1';

start = clock;
com_ntopics = ntopics * com_proportion;
src_ntopics = ntopics - com_ntopics;
tar_ntopics = ntopics - com_ntopics;
for n = 1:nruns
    disp(['Run=',num2str(n),' is running...']);
    tic;
    model(n) = jointMixtureModel( dataset,com_ntopics,src_ntopics,tar_ntopics,smooth,niters );
    results(n) = topicCorrAnalysis( dataset,model(n),ntrain,algorithm,options );
    toc;
end
elapse = etime(clock,start);

save('workspace');