#include "mex.h"
#include "matrix.h"
#include <math.h>
#include <string.h>

/*
  The joint E step in Topic Alignment

  Lianghao Li
*/

void spec_Estep(double *word, double *doc, double *com_Pw_z, double *spec_Pw_z, double *Pz_dpi, double *mu, mwSize nnz, mwSize nwords, mwSize com_ntopics, mwSize spec_ntopics, double *Pz_dw, double *Pw_d);

/*
  input:
    prhs[0]: src_word, term-doc matrix elements' row(word) indices of source domain
    prhs[1]: src_doc, term-doc matrix elements' column(doc) indices of source domain
	prhs[2]: tar_word, term-doc matrix elements' row(word) indices of target domain
	prhs[3]: tar_doc, term-doc matrix elements' column(doc) indices of target domain
	prhs[4]: com_Pw_z, for common topics, size nwords * com_ntopics
    prhs[5]: src_Pw_z, for source domain specifc topics, size nwords * src_ntopics
	prhs[6]: tar_Pw_z, for target domain specifc topics, size nwords * tar_ntopics
    prhs[7]: src_Pz_dpi, for source domain, size (com_ntopics + src_ntopics) * src_ndocs
	prhs[8]: tar_Pz_dpi, for target domain, size (com_ntopics + tar_ntopics) * tar_ndocs
	prhs[9]: src_mu, the parameter for Bernoulli distribution w.r.t each document from source domain
	prhs[10]: tar_mu, the parameter for Bernoulli distribution w.r.t each document from target domain
  output:
    plhs[0]: src_Pz_dw, src_Pz_dw[i,j] is the probability of topic j for <src_word[i],src_doc[i]>, size (com_ntopics + src_ntopics) * src_nnz
	plhs[1]: src_Pw_d, src_Pw_d is used for log-likelihood calculation
    plhs[2]: tar_Pz_dw, tar_Pz_dw[i,j] is the probability of topic j for <tar_word[i],tar_doc[i]>, size (com_ntopics + tar_ntopics) * tar_nnz
	plhs[3]: tar_Pw_d, tar_Pw_d is used for log-likelihood calculation
*/
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double *src_word, *src_doc, *tar_word, *tar_doc, *com_Pw_z, *src_Pw_z, *tar_Pw_z, *src_Pz_dpi, *tar_Pz_dpi, *src_mu, *tar_mu, *src_Pz_dw, *src_Pw_d, *tar_Pz_dw, *tar_Pw_d;
    mwSize src_nnz, tar_nnz, nwords, com_ntopics, src_ntopics, tar_ntopics;

    src_word = mxGetPr(prhs[0]);
    src_doc = mxGetPr(prhs[1]);

	tar_word = mxGetPr(prhs[2]);
    tar_doc = mxGetPr(prhs[3]);

    com_Pw_z = mxGetPr(prhs[4]);
    src_Pw_z = mxGetPr(prhs[5]);
    tar_Pw_z = mxGetPr(prhs[6]);

	src_Pz_dpi = mxGetPr(prhs[7]);
	tar_Pz_dpi = mxGetPr(prhs[8]);

	src_mu = mxGetPr(prhs[9]);
	tar_mu = mxGetPr(prhs[10]);

    src_nnz = mxGetM(prhs[0]);
	tar_nnz = mxGetM(prhs[2]);
	nwords = mxGetM(prhs[4]);
	com_ntopics = mxGetN(prhs[4]);
	src_ntopics = mxGetN(prhs[5]);
	tar_ntopics = mxGetN(prhs[6]);


    if(nrhs != 11)
    {
        printf("usage : [ src_Pz_dw,src_Pw_d,tar_Pz_dw,tar_Pw_d ] = mex_joint_Estep( src_word,src_doc,tar_word,tar_doc,com_Pw_z,src_Pw_z,tar_Pw_z,src_Pz_dpi,tar_Pz_dpi,src_mu,tar_mu );\n");
        return;
    }

    /************************ Main ************************/
    plhs[0] = mxCreateDoubleMatrix(com_ntopics + src_ntopics,src_nnz,mxREAL);
    src_Pz_dw = mxGetPr(plhs[0]);
	plhs[1] = mxCreateDoubleMatrix(src_nnz,1,mxREAL);
	src_Pw_d = mxGetPr(plhs[1]);

    plhs[2] = mxCreateDoubleMatrix(com_ntopics + tar_ntopics,tar_nnz,mxREAL);
    tar_Pz_dw = mxGetPr(plhs[2]);
	plhs[3] = mxCreateDoubleMatrix(tar_nnz,1,mxREAL);
	tar_Pw_d = mxGetPr(plhs[3]);

	spec_Estep(src_word, src_doc, com_Pw_z, src_Pw_z, src_Pz_dpi, src_mu, src_nnz, nwords, com_ntopics, src_ntopics, src_Pz_dw, src_Pw_d);
	spec_Estep(tar_word, tar_doc, com_Pw_z, tar_Pw_z, tar_Pz_dpi, tar_mu, tar_nnz, nwords, com_ntopics, tar_ntopics, tar_Pz_dw, tar_Pw_d);
}

void spec_Estep(double *word, double *doc, double *com_Pw_z, double *spec_Pw_z, double *Pz_dpi, double *mu, mwSize nnz, mwSize nwords, mwSize com_ntopics, mwSize spec_ntopics, double *Pz_dw, double *Pw_d)
{
	mwSize idx, k, offset;
    mwSize w, d, ntopics;

	ntopics = com_ntopics + spec_ntopics;

	/* loop for nnz */
	for(idx = 0; idx < nnz; idx++)
	{
		w = word[idx] - 1;
		d = doc[idx] - 1;
		offset = idx * ntopics;
		
		/* calculate Pz_dw for common topics */
		for(k = 0; k < com_ntopics; k++)
		{
			Pz_dw[offset + k] = mu[d] * com_Pw_z[k * nwords + w] * Pz_dpi[d * ntopics + k];

			Pw_d[idx] += Pz_dw[offset + k];
		}

		/* calculate Pz_dw for domain specific topics */
		for(k = 0; k < spec_ntopics; k++)
		{
			Pz_dw[offset + com_ntopics + k] = (1 - mu[d]) * spec_Pw_z[k * nwords + w] * Pz_dpi[d * ntopics + com_ntopics + k];

			Pw_d[idx] += Pz_dw[offset + com_ntopics + k];
		}

		/* do normalization */
        for(k = 0; k < com_ntopics + spec_ntopics; k++)
        {
            Pz_dw[offset + k] /= Pw_d[idx];
        }
	}
}