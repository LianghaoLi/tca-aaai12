function [ result ] = jointMixtureModel( data,com_ntopics,src_ntopics,tar_ntopics,smooth,niters )
src_X = data.src_X;
tar_X = data.tar_X;

% parameters
if size(src_X,1) ~= size(tar_X,1)
    error('same words size should be contained in two domains');
end
param.com_ntopics = com_ntopics;
param.src_ntopics = src_ntopics;
param.tar_ntopics = tar_ntopics;
param.smooth = smooth;
param.niters = niters;

start = cputime;
[nwords, src_ndocs] = size(src_X);
[~, tar_ndocs] = size(tar_X);
[src_word,src_doc,src_count] = find(src_X);
[tar_word,tar_doc,tar_count] = find(tar_X);
info = [nwords,src_ndocs,tar_ndocs,com_ntopics,src_ntopics,tar_ntopics,smooth];

% joint-topic-model
[src_Pd,tar_Pd,src_Pz_dpi,tar_Pz_dpi,com_Pw_z,src_Pw_z,tar_Pw_z,src_mu,tar_mu] = ...
    initModel( src_X,tar_X,com_ntopics,src_ntopics,tar_ntopics );

src_logPw_d = zeros(niters,1);
tar_logPw_d = zeros(niters,1);
joint_logPw_d = zeros(niters,1);
for n = 1:niters
    % E step
    [ src_Pz_dw,src_Pw_d,tar_Pz_dw,tar_Pw_d ] = ...
        mex_joint_Estep( src_word,src_doc,tar_word,tar_doc,com_Pw_z,src_Pw_z,tar_Pw_z,src_Pz_dpi,tar_Pz_dpi,src_mu,tar_mu );
    
    % logPw_d for *old* model
    [ joint_logPw_d(n),src_logPw_d(n),tar_logPw_d(n) ] = logPw_d( src_count,tar_count,src_Pw_d,tar_Pw_d );
    %fprintf('%d.Log-Likelihood: %4.3f\n',n,joint_logPw_d(n));
    
    % M step
    [ com_Pw_z,src_Pw_z,tar_Pw_z,src_Pz_dpi,tar_Pz_dpi,src_mu,tar_mu ] = ...
        mex_joint_Mstep( src_word,src_doc,src_count,tar_word,tar_doc,tar_count,src_Pz_dw,tar_Pz_dw,info );
end
elapse = cputime - start;

% result
result.param = param;
result.src_Pd = src_Pd;
result.tar_Pd = tar_Pd;
result.src_mu = src_mu;
result.tar_mu = tar_mu;
result.src_Pz_dpi = src_Pz_dpi;
result.tar_Pz_dpi = tar_Pz_dpi;
result.src_logPw_d = src_logPw_d;
result.tar_logPw_d = tar_logPw_d;
result.joint_logPw_d = joint_logPw_d;
result.elapse = elapse;

% mining common topic words and domain specific words
if ~isempty(data.vocabulary)
    vocabulary = data.vocabulary;
    [ com_topicwords ] = docModeling(com_Pw_z,vocabulary);
    [ src_topicwords ] = docModeling(src_Pw_z,vocabulary);
    [ tar_topicwords ] = docModeling(tar_Pw_z,vocabulary);
    result.com_topicwords = com_topicwords;
    result.src_topicwords = src_topicwords;
    result.tar_topicwords = tar_topicwords;
end
end


function [ src_Pd,tar_Pd,src_Pz_dpi,tar_Pz_dpi,com_Pw_z,src_Pw_z,tar_Pw_z,src_mu,tar_mu ] = initModel( src_X,tar_X,com_ntopics,src_ntopics,tar_ntopics )
% Pd
nnzwords = sum(src_X(:)) + sum(tar_X(:));
src_Pd = sum(src_X,1)' ./ nnzwords;
tar_Pd = sum(tar_X,1)' ./ nnzwords;

% Pw_z and Pz_d
src_ndocs = size(src_X,2);
tar_ndocs = size(tar_X,2);

src_Pz_dpi = zeros(com_ntopics+src_ntopics, src_ndocs);
tar_Pz_dpi = zeros(com_ntopics+tar_ntopics, tar_ndocs);
X = [src_X, tar_X];

option.niters = 100;
option.ntopics = com_ntopics;
[com_Pw_z,Pz_d,~,~,~,~,~] = pLSA(X,option);
src_Pz_dpi(1:com_ntopics, :) = Pz_d(:,1:src_ndocs);
tar_Pz_dpi(1:com_ntopics, :) = Pz_d(:,src_ndocs+1:end);

option.ntopics = src_ntopics;
[src_Pw_z,src_Pz_dpi(com_ntopics+1:end,:),~,~,~,~,~] = pLSA(src_X,option);

option.ntopics = tar_ntopics;
[tar_Pw_z,tar_Pz_dpi(com_ntopics+1:end,:),~,~,~,~,~] = pLSA(tar_X,option);

% P_pi
mu = (2 * com_ntopics) / (2 * com_ntopics + src_ntopics + tar_ntopics);
src_mu = repmat(mu,src_ndocs,1);
tar_mu = repmat(mu,tar_ndocs,1);
end


function [ joint_logPw_d,src_logPw_d,tar_logPw_d ] = logPw_d( src_count,tar_count,src_Pw_d,tar_Pw_d )
%% calculate logPw_d as logL
src_logPw_d = sum(src_count .* log(src_Pw_d));
tar_logPw_d = sum(tar_count .* log(tar_Pw_d));
joint_logPw_d = src_logPw_d + tar_logPw_d;
end

